import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Put a short phrase describing the program here.
 *
 * @author Marshall Bott :)
 *
 */
public final class TagCloudv3 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudv3() {
    }

    /**
     *
     */
    private static final String SEPARATORS = " \t\n\r\"(),.[]*'!?{}-";

    /**
     * Using this to tokenize file. Copied from tokenizer
     *
     * @param text
     * @param position
     * @return String or Separator
     */
    private static String nextWordOrSeparator(String text, int position) {
        assert text != null : "Violation of: text is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";
        int end = position + 1;
        boolean start = SEPARATORS.indexOf(text.charAt(position)) >= 0;
        while (text.length() > end
                && start == (SEPARATORS.indexOf(text.charAt(end)) >= 0)) {
            end++;
        }
        return text.substring(position, end);
    }

    /**
     * Compares numbers.
     *
     */
    private static class orderword implements Comparator<Pair> {
        @Override
        public int compare(Pair o1, Pair o2) {
            int x = o1.key().compareTo(o2.key());
            return x;
        }
    }

    /**
     * Compares numbers.
     *
     */
    private static class ordernum implements Comparator<Pair> {
        @Override
        public int compare(Pair o1, Pair o2) {
            //Count
            int x = o2.value().compareTo(o1.value());
            if (x == 0) {
                //Keys
                x = o1.key().compareTo(o2.key());
            }
            return x;
        }
    }

    /**
     * I'm unsure what it wants here but this is just a pair that I use instead
     * of map.entry because I was told map.entry was bad.
     *
     * @author bigmu
     *
     */
    private static class Pair {
        /**
         * The key.
         */
        String key;
        /**
         * The value.
         */
        Integer value;

        /**
         *
         * @param k
         * @param val
         */
        Pair(String k, Integer val) {
            this.key = k;
            this.value = val;
        }

        /**
         *
         * @return this.key
         */
        String key() {
            return this.key;
        }

        /**
         *
         * @return this.value
         */
        Integer value() {
            return this.value;
        }
    }

    /**
     * builds a specific html copied from the example. almost identical to v2
     * but with java components instead.
     *
     * @param outfile
     *            html page being printed to
     * @param keylist
     *            an ordered list of word pairs, in the order in which they will
     *            print, should be cleared at the end
     * @param max
     *            the largest count in the top 100
     * @param min
     *            the lowest count in the top 100
     * @param filename
     *            the name of the infile
     */
    private static void buildpage(PrintWriter outfile, List<Pair> keylist,
            int max, int min, String filename) {
        int count = keylist.size();
        final double maxfont = 36.0;
        final double minfont = 12.0;
        //Build an html page :)
        //I'm not commenting this, its all annoying html formating copied from the example
        String title = "Top " + count + " words in " + filename;
        outfile.println("<html><head><meta http-equiv=\"Content-Type\" "
                + "content=\"text/html; charset=UTF-8\">");
        outfile.println("<title>" + title + "</title>");
        //This is just where the tagcloud.css is
        outfile.println("<link href=\"./tagCloud/tagcloud.css\""
                + " rel=\"stylesheet\" type=\"text/css\">");
        outfile.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\""
                        + " rel=\"stylesheet\" type=\"text/css\">");
        outfile.println("</head>");
        outfile.println("<body>");
        outfile.println("<h2>" + title + "</h2>");
        outfile.println("<hr>");
        outfile.println("<div class=\"cdiv\">");
        outfile.println("<p class=\"cbox\">");
        //Mark
        while (keylist.size() > 0) {
            Pair val = keylist.remove(0);
            //A complex formula to get font (Someone told me to do this one)
            double font = (maxfont * (val.value() - min) / (max - min))
                    + minfont;
            outfile.println("<span style=\"cursor:default\" class=\"f"
                    + (int) font + "\" title=\"count: " + val.value() + "\">"
                    + val.key() + "</span>");
        }
        outfile.println("</p>");
        outfile.println("</div>");
        outfile.println("</body></html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        //Args ------
        Scanner stdin = new Scanner(System.in);
        System.out.println("Enter a file name to be read: ");
        String inname = stdin.nextLine();
        System.out.println("Enter a file to be printed to: ");
        String outname = stdin.nextLine();
        //data/importance.txt
        //data/importance.html
        //Should check to make sure its a number?
        System.out.println("How many words do you want? ");
        int count = stdin.nextInt();

        stdin.close();
        //Open infile
        BufferedReader infile;
        try {
            infile = new BufferedReader(new FileReader(inname));
        } catch (IOException e) {
            System.err.println("Error opening infile: " + inname);
            return;
        }

        //Read infile
        //Build a map of all words -----
        Map<String, Integer> map = new HashMap<String, Integer>();
        try {
            String temp = infile.readLine();
            //Reads each line until its out
            while (temp != null) {
                int pos = 0;
                //Tokenizes each line
                while (temp.length() > pos) {
                    String s = nextWordOrSeparator(temp, pos);
                    pos += s.length();
                    if (SEPARATORS.indexOf(s.charAt(0)) < 0) {
                        s = s.toLowerCase();
                        if (!map.containsKey(s)) {
                            map.put(s, 1);
                        } else {
                            int x = map.get(s);
                            map.remove(s);
                            map.put(s, x + 1);
                        }
                    }
                }
                temp = infile.readLine();
            }
        } catch (IOException e) {
            System.err.println("Error adding infile to map: " + inname);
        }

        //We are done with infile
        //Close infile
        try {
            //We do not cross streams
            infile.close();
        } catch (IOException e) {
            System.err.println("Error closing infile: " + inname);
        }

        //Get top 100 in map, sort numerically -----
        //Build a list
        List<Pair> numlist = new LinkedList<Pair>();
        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        //Add all
        for (Map.Entry<String, Integer> e : entries) {
            Pair p = new Pair(e.getKey(), e.getValue());
            numlist.add(p);
        }
        //We don't use map anymore
        Comparator<Pair> compnum = new ordernum();
        Collections.sort(numlist, compnum);

        //Sort alphabetically ------
        //Build a list
        List<Pair> wordlist = new LinkedList<Pair>();

        //Add top *count*
        //Should remove top count from numlist but we don't use it again
        int max = numlist.get(0).value();
        int min = numlist.get(count - 1).value();
        for (int i = 0; i < count; i++) {
            if (numlist.size() > 0) {
                Pair e = numlist.remove(0);
                wordlist.add(e);
            } else {
                //Technically an error but it should just keep running
                System.out.println("Count exceeded number of words");
            }
        }

        //Sort
        Comparator<Pair> compword = new orderword();
        Collections.sort(wordlist, compword);

        //Open outfile
        PrintWriter outfile;
        try {
            outfile = new PrintWriter(
                    new BufferedWriter(new FileWriter(outname)));
        } catch (IOException e) {
            System.err.println("Error opening outfile: " + outname);
            return;
        }

        //Print to outfile
        buildpage(outfile, wordlist, max, min, inname);

        //Close outfile
        outfile.close();
    }

}
